-- AlterTable
ALTER TABLE "Organization" ALTER COLUMN "password" DROP NOT NULL;
